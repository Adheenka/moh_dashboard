from odoo import models, fields, api

class KsDashboardNinjaItems(models.Model):
    _inherit = 'ks_dashboard_ninja.item'


    # New fields for the 'Topics' section
    topic_name = fields.Char(string="Topic Name")
    company_name = fields.Char(string="Company Name", default=lambda self: self.env.user.company_id.name)
    type = fields.Selection([('topic', 'Topic')], string="Type", default='topic')

    @api.depends('ks_dn_header_lines', 'ks_dashboard_item_type')
    def ks_get_to_do_view_data(self):
        for rec in self:
            ks_to_do_data = rec._ksGetToDOData()
            rec.ks_to_do_data = ks_to_do_data